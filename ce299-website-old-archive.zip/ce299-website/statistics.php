<?php
  // Set the page title and include the header file
  $pageTitle = "Statistics";
  require_once("template/header.php");
?>


  
<?php

  echo "<img src='python\images\scans.png' class='images' class='column' alt='graph of scans' />"; 

  echo "<img src='python\images\\readers.png' class='images' class='column' alt='graph of readers'/>"; 
  
  echo "<img src='python\images\departments2.png' class='images' class='column' alt='graph of departments'/>";

  echo "<img src='python\images\departments3.png' class='images' class='column' alt='graph of departments' />";

  echo "<img src='python\images\departments1.png' class='images' class='column' alt='graph of departments' />";
 
  echo "<img src='python\images\ScanKMeans.png' class='images' class='column' alt='graph of K Means' />";
  
?>

 <!DOCTYPE html>
<html>
<style>

.images {
   background-color: #f1f1f1;
   height: 380px;
   width: 600px;
   padding: 20px;
   box-sizing: border-box;
   margin-top: 50px;
   margin-right: 80px;
   margin-left: 65px;
   margin-bottom: 25px;
   border: 5px;
   opacity: 5;
}

img:hover {
	color: #f1f1f1; 
	}

</style>
</html>


<?php 
  // Include the footer template file
  require_once("template/footer.php");
?>