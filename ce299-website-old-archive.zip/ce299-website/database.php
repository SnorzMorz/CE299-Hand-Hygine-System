<?php

$host = "my-testing.mysql.database.azure.com";
$database = "ce299";
$userName = "yl19052@my-testing";
$password = "CE299_Team06";

function connectDB(){
	// Create connection
	$connection = mysqli_init();
	mysqli_ssl_set($con, NULL, NULL, "../DigiCertGlobalRootCA.crt.pem", NULL, NULL); 
	mysqli_real_connect($connection, $host, $userName, $password, $database, 3306);
	if (mysqli_connect_errno($connection)) {
		die("Failed to connect to MySQL: " + mysqli_connect_error());
	} else {
		return "<h2>Connected to the database</h2>";
	}
	return $connection;
} 

function last30Day() {
	$date = date("Y-m-d");
	
	$dateArray = array();
	$day = "day";
	

	for ($i=0; $i < 30; $i++) {
		$requirment = strtotime("-" . $i . " day");
		$date = date("Y-m-d", $requirment);

		// Push the element to the end of array
		array_push($dateArray, $date);

	}
	return $dateArray;
}

// Retrieve number of scans on each specific date
function countScans($arrayOfDate, $connection) {
	$dailyCount = array();

	foreach ($arrayOfDate as $date) {
		$escapeChars = mysqli_real_escape_string($connection, $date);
		$start = $date . " 00:00:00";
		$end = $date . " 23:59:59";
		$query = "SELECT scans.Scan FROM scans WHERE scans.Scan >= '$start' and scans.Scan <= '$end'";

		$result = mysqli_query($connection, $query);
		$rowOfResult = mysqli_num_rows($result);

		array_push($dailyCount, $rowOfResult);
	}

	return $dailyCount;
}