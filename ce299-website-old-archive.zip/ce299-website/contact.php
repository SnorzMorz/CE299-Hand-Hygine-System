<?php
  // Set the page title and include the header file
  $pageTitle = "Contact";
  require_once("template/header.php");
?>
  <!-- Page Content -->
  <style>
body 
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
  color: #6699cc;

  
}

input[type=submit] {
  background-color: #6699cc;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: darkgray;
}

</style>
</head>
<body>

<div class="w3-text-blue-grey w3-display-topmiddle" style="padding-top:170px">
  <h3>Contact Form</h3>
</div>

<div class="w3-container w3-blue-grey w3-display-bottommiddle" style="width:50%">
  <form name="form" id="form" class="contact-form" action="send.php" method="post">
    <label for="name">First Name</label>
    <input type="text" id="name" name="name" placeholder="Your name..">

    <label for="mail">E-mail address</label>
    <input type="text" id="mail" name="mail" placeholder="Your e-mail..">

    <label for="subject">Subject</label>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>

    <button type="submit" value="Submit" name="submit" id="submit">Submit</button>
  </form>
</div>


    

<?php 
  // Include the footer template file
  require_once("template/footer.php");
?>