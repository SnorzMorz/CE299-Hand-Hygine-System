<?php

require ("newDatabase.php");

if (isset($_POST['name']) && isset($_POST['mail']) && isset($_POST['subject'])){
	require ("contact.php");

	$name=$conn->real_escape_string($_POST['name']);
	$mail=$conn->real_escape_string($_POST['mail']);
	$subject=$conn->real_escape_string($_POST['subject']);

	
	$sql = "INSERT INTO form(name, mail, subject) VALUES('".$name."','".$mail."', '".$subject."')";
	$result = $conn->query($sql);

	if(!$result){
	echo "Please fill Name and Email ";
	}
	else
	{
	echo "Thank you! We will contact you soon";
	}
}
?>