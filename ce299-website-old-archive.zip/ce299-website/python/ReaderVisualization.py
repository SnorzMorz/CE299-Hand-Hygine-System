# This is modified from Joseph's CreateUserVisualization.py
#### Imports####
import matplotlib.pyplot as plt
import mysql.connector
import numpy as np
import pandas as pd

#### Database connection Details####
HOST = "127.0.0.1"
DATABASE = "ce299"
USER = "root"
PASSWORD = ""
PORT = "3306"


#### Code####

# For getting dataframe from database
def getRows(mySql_table_query):
    connection = mysql.connector.connect(
        host=HOST, database=DATABASE, user=USER, password=PASSWORD)
    cursor = connection.cursor()

    # This is the SQL query used to query the database
    # mySql_table_query = """SELECT * FROM scans"""

    # Get Dataframe from sql query
    df = pd.read_sql(mySql_table_query, con=connection)

    if connection:
        cursor.close()
        connection.close()
    return df


# User pie chart of no. times using each hand sanitiser####

#  DataFrame fields:
#      location from reader table
#      number of occurances (i.e. CCOUNT(*))

pieFrame = getRows("""
SELECT reader.location, COUNT(distinct(UserID))
FROM scans
RIGHT JOIN reader ON scans.ReaderID = reader.ReaderID
WHERE scans.ReaderID = reader.ReaderID
GROUP BY reader.location
ORDER BY reader.location
""")




# Renames the COUNT(*) column into something which I can use to reference the column
pieFrame.rename(columns={'COUNT(distinct(UserID))': 'xNum'}, inplace=True)
plt.xlabel("Scans")
# Creation of the pie chart
plt.barh(  # creates a pie chart in plt. plt is like JFrame in Java
    pieFrame.location,  # labels the name of each segment
    pieFrame.xNum,  # data from the dataframe that each of the segments are sized after
)
plt.title("Scans per reader location")
plt.gcf().set_size_inches(14, 6)
plt.savefig("python\\images\\readers.png", transparent=True)
