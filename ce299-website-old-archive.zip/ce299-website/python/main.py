from flask import Flask, render_template
app = Flask(__name__)
import matplotlib
import matplotlib.pyplot as plt
import urllib
import webbrowser

@app.route('/')
def index():
  return render_template('statistics.html')

@app.route('/my-link/')
def my_link():
  print ('I got clicked!')
  plt.plot([0, 60, 10, 40, 50, 80], [0, 3, 10, 15, 20, 50])

  plt.xlabel('Months')
  plt.ylabel('Books Read')

  plt.show()

  return webbrowser.open('http://example.com')

if __name__ == '__main__':
  app.run(debug=True)