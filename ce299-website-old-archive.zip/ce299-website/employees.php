<?php
  // Set the page title and include the header file
  $pageTitle = "Employees";
  require_once("template/header.php");
?>

  <!-- Seach Box -->
  <div class="w3-card-4 w3-display-middle" style="width:600px; padding-bottom: 10px">
    <div class="w3-container w3-blue-gray">
      <h2>Search Employee</h2>
    </div>
    <form class="w3-container" action="/action_page.php">    
      <label class="w3-text-blue-gray"><b>Name</b></label>
      <input class="w3-input w3-border w3-light-gray" name="name" type="text">
      <button class="w3-btn w3-blue-gray">Search</button>
    </form>
  </div>


  <!-- Explanation on bottom -->
  <div class="w3-container w3-border w3-large w3-display-bottommiddle">
    <div class="w3-left-align"><p>Each employee can be searched by name and if identified successfully, a new page with the user's profile and hand hygiene plot will appear.</p></div>
  </div>

  
  
    

<?php 
  // Include the footer template file
  require_once("template/footer.php");
?>