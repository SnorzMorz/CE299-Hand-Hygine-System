<?php
  // Set the page title and include the header file
  $pageTitle = "Administrator";
  require_once("template/header.php");
?>
  <!-- Page Content -->
  <div class="w3-container w3-border w3-large w3-display-middle">
    <div class="w3-left-align"><p>A page for admin?.</p></div>
    <?php
    connect();
    $link = connect();
    $user_sql = "select * from user";
	if($result = mysqli_query($link,$user_sql )){
		if(mysqli_num_rows($result) > 0){?>
        <table>
            <tr>
                <th>UserID</th>
                <th>RFID</th>
                <th>UserName</th>
                <th>Department</th>
            </tr>
        <?php
        
                while($row = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$row['UserID']."</td>";
                    echo "<td>".$row['RFID']."</td>";
                    echo "<td>".$row['UserName']."</td>";
                    echo "<td>".$row['Department']."</td>";
                    echo "</tr>";
                }
                // Free result set
                mysqli_free_result($result);
            } else{
                echo "No records matching your query were found.";
            }
	} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
	}
    ?>
    </table>
    
    
    <?php
    connect();
    $link = connect();
    $user_sql = "select * from scan";
	if($result = mysqli_query($link,$user_sql )){
		if(mysqli_num_rows($result) > 0){?>
        <table>
            <tr>
                <th>ScanID</th>
                <th>UserID</th>
                <th>ReaderID</th>
                <th>Scan</th>
            </tr>
        <?php
        
                while($row = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$row['ScanID']."</td>";
                    echo "<td>".$row['UserID']."</td>";
                    echo "<td>".$row['ReaderID']."</td>";
                    echo "<td>".$row['Scan']."</td>";
                    echo "</tr>";
                }
                // Free result set
                mysqli_free_result($result);
            } else{
                echo "No records matching your query were found.";
            }
	} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
	}
    ?>
    </table>
    
    <?php
    connect();
    $link = connect();
    $user_sql = "select * from user";
	if($result = mysqli_query($link,$user_sql )){
		if(mysqli_num_rows($result) > 0){?>
        <table>
            <tr>
                <th>UserID</th>
                <th>RFID</th>
                <th>UserName</th>
                <th>Department</th>
            </tr>
        <?php
        
                while($row = mysqli_fetch_array($result)){
                    echo "<tr>";
                    echo "<td>".$row['UserID']."</td>";
                    echo "<td>".$row['RFID']."</td>";
                    echo "<td>".$row['UserName']."</td>";
                    echo "<td>".$row['Department']."</td>";
                    echo "</tr>";
                }
                // Free result set
                mysqli_free_result($result);
            } else{
                echo "No records matching your query were found.";
            }
	} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
	}
    ?>
    </table>
  </div>

    

<?php 
  // Include the footer template file
  require_once("template/footer.php");
?>