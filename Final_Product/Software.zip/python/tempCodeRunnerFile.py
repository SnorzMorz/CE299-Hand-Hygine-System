    SELECT reader.location, COUNT(distinct(UserID))
    FROM scans
    RIGHT JOIN reader ON scans.ReaderID = reader.ReaderID
    WHERE scans.ReaderID = reader.ReaderID
    GROUP BY reader.location
    ORDER BY reader.location
    """)